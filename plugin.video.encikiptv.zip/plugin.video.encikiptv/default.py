# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2017 - Encik IPTV
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.encikiptv'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("Best of Suria Records", "channel/UCBd5pENmJrvi6PQq-2ndBhw", 'https://raw.githubusercontent.com/ndroid23/xml/master/icon256x256.png'),
        ("Best of Nagaswara", "channel/UCuBCaQe-17deJk3ne78TQ6g", 'https://raw.githubusercontent.com/ndroid23/xml/master/icon256x256.png'),
        ("Best of Mixology", "channel/UCT6j1xwFKQoZnQy3nWJai5Q", 'https://raw.githubusercontent.com/ndroid23/xml/master/icon256x256.png'),
        ("Koleksi Filem Melayu 80an-90an", "channel/UCYAlnsQviE-c4STLzz_fPgA", 'https://raw.githubusercontent.com/ndroid23/xml/master/icon256x256.png'),		
			
]



# Entry point
def run():
    plugintools.log("encikiptv.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("encikiptv.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()